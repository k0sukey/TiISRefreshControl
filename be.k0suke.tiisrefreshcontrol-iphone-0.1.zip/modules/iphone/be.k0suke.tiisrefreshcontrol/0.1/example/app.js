// this sets the background color of the master UIView (when there are no windows/tab groups on it)
Titanium.UI.setBackgroundColor('#000');

// create tab group
var tabGroup = Titanium.UI.createTabGroup();


//
// create base UI tab and root window
//
var win1 = Titanium.UI.createWindow({  
    title:'Tab 1',
    backgroundColor:'#fff',
    extendEdges: [Ti.UI.EXTEND_EDGE_BOTTOM, Ti.UI.EXTEND_EDGE_TOP],
    autoAdjustScrollViewInsets: true
});


var tableView = Ti.UI.createTableView({
  refreshControlEnabled: false,
  data: [
    {title:"Lorem ipsum"},
    {title:"Dolor sit amet"},
    {title:"Lorem ipsum"},
    {title:"Dolor sit amet"},
    {title:"Lorem ipsum"},
    {title:"Dolor sit amet"},
    {title:"Lorem ipsum"},
    {title:"Dolor sit amet"},
    {title:"Lorem ipsum"},
    {title:"Dolor sit amet"},
    {title:"Lorem ipsum"},
    {title:"Dolor sit amet"},
    {title:"Lorem ipsum"},
    {title:"Dolor sit amet"},
    {title:"Lorem ipsum"},
    {title:"Dolor sit amet"}]
});

win1.add(tableView);

tableView.setContentInsets.setContentInsets({top:0}, {animated:true});
setTimeout(function() {
  tableView.setContentInsets.setContentInsets({top:60}, {animated:true});
}, 2000);
setTimeout(function() {
  tableView.setContentInsets.setContentInsets({top:0}, {animated:true});
}, 4000);

var tab1 = Titanium.UI.createTab({  
    icon:'KS_nav_views.png',
    title:'Tab 1',
    window:win1
});



//
// create controls tab and root window
//
var win2 = Titanium.UI.createWindow({  
    title:'Tab 2',
    backgroundColor:'#fff'
});
var tab2 = Titanium.UI.createTab({  
    icon:'KS_nav_ui.png',
    title:'Tab 2',
    window:win2
});

var label2 = Titanium.UI.createLabel({
  color:'#999',
	text:'I am Window 2',
	font:{fontSize:20,fontFamily:'Helvetica Neue'},
	textAlign:'center',
	width:'auto'
});

win2.add(label2);



//
//  add tabs
//
tabGroup.addTab(tab1);  
tabGroup.addTab(tab2);  


// open tab group
tabGroup.open();